int x = 0;
print("I have ")
print(x)
print(" apple(s)\n");