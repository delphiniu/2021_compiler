int x = 0;
while(x > 10) {
    print(x);
}

while(true) {
    print("TRUE\n");
    x++;
    if (x == 10) {
        break;
    }
}